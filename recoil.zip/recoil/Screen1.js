import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  Image,
  FlatList,
} from 'react-native';
import React, { useState, useEffect } from 'react';

import search from './assets/search.png';
import check from './assets/check.png';
import pen from './assets/pen.png';

import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';
import {
  itemsState,
  loadingState,
  errorState,
  fetchAllItemsSelector,
} from './recoilState';

export default function Screen1({ navigation, route }) {
  const [items, setItems] = useRecoilState(itemsState); 
  const setLoading = useSetRecoilState(loadingState);
  const setError = useSetRecoilState(errorState);
  const fetchedItems = useRecoilValue(fetchAllItemsSelector); // Lấy dữ liệu từ selector

  const [data, setData] = useState(items);
  const [textSearch, setTextSearch] = useState('');

  // const fetchData = async () => {
  //   const fetchedItems = await fetchAllItemsSelector.get();
  //   setItems(fetchedItems);
  // };

  useEffect(() => {
    setItems(fetchedItems); // Cập nhật items trong Recoil
  }, [fetchedItems]);

  const addData = async (valueAdd) => {
    const response = await fetch(
      'https://6708715e8e86a8d9e42eecda.mockapi.io/api/job',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value: valueAdd }),
      }
    );
    if (!response.ok) throw new Error('Failed to add item');
    const newItem = await response.json();
    setItems((oldItems) => [...oldItems, newItem]); 
  };

  useEffect(() => {
    setData(items);
  }, [items]);

  useEffect(() => {
    if (route.params?.valueAdd) {
      addData(route.params?.valueAdd);
    }
  }, [route.params?.valueAdd]);

  const searchData = (text) => {
    setTextSearch(text);
    if (text !== '') {
      let search = data.filter((item) => item.value.includes(text));
      setData(search);
    } else {
      fetchData();
    }
  };

  const Item = ({ item }) => (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        gap: 20,
        backgroundColor: 'grey',
        borderRadius: 10,
        padding: 8,
        margin: 5,
      }}>
      <Image source={check} />
      <Text>{item.value}</Text>
      <TouchableOpacity
        onPress={() =>
          navigation.navigate('screen2', { action: 'update', item: item })
        }>
        <Image source={pen} />
      </TouchableOpacity>
    </View>
  );

  console.log('route: ', route.params);

  return (
    <View
      style={{
        flex: 1,
        alignItems: 'center',
        backgroundColor: 'white',
        padding: 8,
        gap: 15,
      }}>
      <View
        style={{
          flexDirection: 'row',
          gap: 10,
          borderWidth: 1,
          borderRadius: 10,
          padding: 10,
        }}>
        <Image source={search} />
        <TextInput
          placeholder="Search"
          style={{ color: 'grey', width: 250 }}
          onChangeText={searchData}
          value={textSearch}
        />
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <Item item={item} />}
      />

      <TouchableOpacity
        style={{
          backgroundColor: 'blue',
          borderRadius: '50%',
          paddingHorizontal: 30,
          paddingVertical: 20,
          marginVertical: 30,
        }}
        onPress={() => navigation.navigate('screen2', { action: 'add' })}>
        <Text style={{ color: 'white', fontSize: 18, fontWeight: 450 }}>+</Text>
      </TouchableOpacity>
    </View>
  );
}
