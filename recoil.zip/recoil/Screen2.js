import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  Image,
} from 'react-native';
import React, { useState, useEffect } from 'react';

import book from './assets/note.png';

export default function Screen2({ navigation, route }) {
  const [valueAdd, setValueAdd] = useState('');
  const [valueUpdate, setValueUpdate] = useState('');
  const [action, setAction] = useState('');

  useEffect(() => {
    setAction(route.params?.action);
  }, []);

  const handlePayload = (text) => {
    action === 'add' ? setValueAdd(text) : setValueUpdate(text)
  };

// console.log('3: ', route.params)
  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 25, fontWeight: 600, color: 'black' }}>
        {action === 'add' ? 'ADD' : 'UPATE'} YOUR JOB
      </Text>

      <View
        style={{
          flexDirection: 'row',
          gap: 10,
          borderWidth: 1,
          borderRadius: 10,
          padding: 10,
        }}>
        <Image
          source={book}
          style={{ width: 20, height: 20 }}
          resizeMode="contain"
        />
        <TextInput
          placeholder="input put your job"
          style={{ color: 'grey', width: 250 }}
          onChangeText={handlePayload}
        />
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: 'blue',
          borderRadius: 10,
          paddingHorizontal: 30,
          paddingVertical: 10,
          marginVertical: 30,
        }}
        onPress={() =>
          navigation.navigate(
            'screen1',
            action === 'add' ? { valueAdd } : { valueUpdate: valueUpdate, idUpdate: route.params?.item.id }
          )
        }>
        <Text style={{ color: 'white', fontSize: 18, fontWeight: 450 }}>
          FINISH ->
        </Text>
      </TouchableOpacity>

      <Image
        source={book}
        style={{ width: 200, height: 200 }}
        resizeMode="contain"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 8,
    gap: 15,
  },
});
