// recoilState.js
import { atom, selector } from 'recoil';

// Atom lưu trữ danh sách items
export const itemsState = atom({
  key: 'itemsState', 
  default: [], 
});

// Atom lưu trữ trạng thái loading
export const loadingState = atom({
  key: 'loadingState',
  default: false,
});

// Atom lưu trữ thông tin lỗi
export const errorState = atom({
  key: 'errorState',
  default: null,
});

// Selector cho việc lấy tất cả items từ API
export const fetchAllItemsSelector = selector({
  key: 'fetchAllItemsSelector',
  get: async () => {
    try {
      const response = await fetch('https://6708715e8e86a8d9e42eecda.mockapi.io/api/job');
      if (!response.ok) throw new Error('Failed to fetch items');
      return await response.json();
    } catch (error) {
      throw error.message;
    }
  },
});
