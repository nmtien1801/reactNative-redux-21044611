// rootSaga.js
import { takeEvery, call, put } from 'redux-saga/effects';
import {
  ADD_ITEM,
  addItemSuccess,
  addItemFailure,
  GET_ALL_ITEMS,
  getAllItems,
  getAllItemsSuccess,
  getAllItemsFailure,
} from './Action'; // Import action

const fetchAllItems = async () => {
  const response = await fetch(
    'https://6708715e8e86a8d9e42eecda.mockapi.io/api/job'
  );
  if (!response.ok) {
    throw new Error('Failed to fetch items');
  }
  return await response.json();
};

function* getAllItemsSaga() {
  try {
    const items = yield call(fetchAllItems); // Gọi API
    yield put(getAllItemsSuccess(items)); // Dispatch thành công
  } catch (error) {
    yield put(getAllItemsFailure(error.message)); // Dispatch thất bại
  }
}

// Giả sử bạn có một hàm API để thêm mục
// Hàm gọi API với phương thức POST
const addData = async (valueAdd) => {
  let res = await fetch('https://6708715e8e86a8d9e42eecda.mockapi.io/api/job', {
    method: 'POST',
    headers: { 'content-Type': 'application/json' },
    body: JSON.stringify(valueAdd),
  });
  if (res.ok) alert('add success');

  // await fetchAllItems();
};

function* addItemSaga(action) {
  try {
    const item = yield call(addData, action.payload); // Gọi API
    yield put(addItemSuccess(item)); // Thêm item thành công
    yield put(getAllItems());
  } catch (error) {
    yield put(addItemFailure(error.message)); // Thêm item thất bại
  }
}

export default function* watchAddItem() {
  yield takeEvery(ADD_ITEM, addItemSaga); // Lắng nghe ADD_ITEM
  yield takeEvery(GET_ALL_ITEMS, getAllItemsSaga);
}
