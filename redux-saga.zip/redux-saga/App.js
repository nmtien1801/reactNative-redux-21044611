import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createContext, useContext, useState } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import store from './store';

import Screen1 from './Screen1';
import Screen2 from './Screen2';

import Header from './Header';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <Provider store={store}>
      <UserProfile />
    </Provider>
  );
}

const UserProfile = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="screen1">
        <Stack.Screen
          name="screen1"
          component={Screen1}
          options={{
            header: () => {},
          }}
        />
        <Stack.Screen
          name="screen2"
          component={Screen2}
          // optionS = {}
          // ({}) => ({ header: ()=> <> })
          options={({ route, navigation }) => ({
            header: () => <Header route={route} navigation={navigation} />,
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({});
