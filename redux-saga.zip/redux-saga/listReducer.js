import {
  ADD_ITEM,
  ADD_ITEM_SUCCESS,
  ADD_ITEM_FAILURE,
  REMOVE_ITEM,
  SET_ITEMS,
  GET_ALL_ITEMS,
  GET_ALL_ITEMS_SUCCESS,
  GET_ALL_ITEMS_FAILURE,
} from './Action';

const initialState = {
  items: [
    // { value: 'Ricky Beer', id: '1' },
    // { value: 'Lynn Auer', id: '2' },
    // { value: 'Patsy Bernier', id: '3' },
    // { value: 'Cecilia Tromp', id: '4' },
  ],
  loading: false,
  error: null,
};

const listReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_ALL_ITEMS:
      return {
        ...state,
        loading: true, // Bắt đầu quá trình lấy dữ liệu
        error: null, // Đặt lại thông tin lỗi
      };
    case GET_ALL_ITEMS_SUCCESS:
      return {
        ...state,
        items: action.payload, // Cập nhật items với dữ liệu nhận được
        loading: false, // Kết thúc quá trình lấy dữ liệu
      };
    case GET_ALL_ITEMS_FAILURE:
      return {
        ...state,
        loading: false, // Kết thúc quá trình lấy dữ liệu
        error: action.payload, // Lưu thông tin lỗi
      };

    case ADD_ITEM:
      return {
        ...state,
        loading: true, // Bắt đầu quá trình thêm item
        error: null, // Đặt lại thông tin lỗi
      };
    case ADD_ITEM_SUCCESS:
      return {
        ...state,
        // items: [...state.items, action.payload],
        loading: false, // Kết thúc quá trình thêm item
      };
    case ADD_ITEM_FAILURE:
      return {
        ...state,
        loading: false, // Kết thúc quá trình thêm item
        error: action.payload, // Lưu thông tin lỗi
      };
    case REMOVE_ITEM:
      return {
        ...state,
        items: state.items.filter((item, index) => index !== action.payload),
      };
    case SET_ITEMS:
      return {
        ...state,
        items: action.payload,
      };
    default:
      return state;
  }
};

export default listReducer;
