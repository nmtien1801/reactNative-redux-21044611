// rootReducer.js
import { combineReducers } from 'redux';
import listReducer from './listReducer'; // Import reducer danh sách

const rootReducer = combineReducers({
  list: listReducer, // Kết hợp reducer để khi dùng thì gọi action.list.value
});

export default rootReducer; // Xuất reducer gốc
