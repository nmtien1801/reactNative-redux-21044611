// actions.js
export const GET_ALL_ITEMS = 'GET_ALL_ITEMS';
export const GET_ALL_ITEMS_SUCCESS = 'GET_ALL_ITEMS_SUCCESS';
export const GET_ALL_ITEMS_FAILURE = 'GET_ALL_ITEMS_FAILURE';

export const ADD_ITEM = 'ADD_ITEM';
export const ADD_ITEM_SUCCESS = 'ADD_ITEM_SUCCESS';
export const ADD_ITEM_FAILURE = 'ADD_ITEM_FAILURE';

export const getAllItems = () => ({
  type: GET_ALL_ITEMS,
});

export const getAllItemsSuccess = (items) => ({
  type: GET_ALL_ITEMS_SUCCESS,
  payload: items,
});

export const getAllItemsFailure = (error) => ({
  type: GET_ALL_ITEMS_FAILURE,
  payload: error,
});

export const addItem = (data) => ({
  type: ADD_ITEM,
  payload: data,
});

export const addItemSuccess = (data) => ({
  type: ADD_ITEM_SUCCESS,
  payload: data,
});

export const addItemFailure = (error) => ({
  type: ADD_ITEM_FAILURE,
  payload: error,
});
