import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Thunks for async actions
export const fetchAllItems = createAsyncThunk(
  'items/fetchAllItems',
  async (_, { rejectWithValue }) => {
    try {
      const response = await fetch(
        'https://6708715e8e86a8d9e42eecda.mockapi.io/api/job'
      );
      if (!response.ok) {
        throw new Error('Failed to fetch items');
      }
      return await response.json();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const addItem = createAsyncThunk(
  'items/addItem',
  async (data, { rejectWithValue, dispatch }) => {
    try {
      const response = await fetch(
        'https://6708715e8e86a8d9e42eecda.mockapi.io/api/job',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        }
      );
      if (!response.ok) {
        throw new Error('Failed to add item');
      }
      const item = await response.json();
      dispatch(fetchAllItems());
      return item;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const itemsSlice = createSlice({
  name: 'items',
  initialState: {
    items: [],
    loading: false,
    error: null,
  },
  reducers: {
    removeItem: (state, action) => {
      state.items = state.items.filter((_, index) => index !== action.payload);
    },
    setItems: (state, action) => {
      state.items = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllItems.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllItems.fulfilled, (state, action) => {
        state.items = action.payload;
        state.loading = false;
      })
      .addCase(fetchAllItems.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(addItem.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addItem.fulfilled, (state, action) => {
        state.items.push(action.payload);
        state.loading = false;
      })
      .addCase(addItem.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { removeItem, setItems } = itemsSlice.actions;
export default itemsSlice.reducer;
